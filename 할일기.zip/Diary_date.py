from diary import Date

class contents:

    def __init__(self):
        self.diary_list = []

    def write_diary(self):
        title = input("제목을 입력해주세요 >> ")
        #다이어리 객체 만들기
        diary_date = Date(title)
        #다이어리 속성 설정하기
        diary_date.set_diary()
        #다이어리 self.diary_list에 어펜드하기
        self.diary_list.append(diary_date)

    def modify_diary(self):
        pass

    def delete_diary(self):
        pass

    def show_diary(self):
        for index, diary in enumerate(self.diary_list):
            print(f'{index + 1} : {Date.Title}')

    def __str__(self):
        pass
