from Diary_date import contents

def print_menu():
    print('1, 일기 작성')
    print('2, 일기 수정')
    print('3, 일기 삭제')
    print('4, 이때까지 작성한 일기 확인')
    print('5, 종료하기')
    num = input('메뉴를 선택해주세용 >> ')
    return num

def main():
    diary = contents()

    while True:
        num = print_menu()
        if num == '1':
            # 일기 작성
            diary.write_diary()
        if num == '2':
            # 일기 수성
            diary.modify_diary()
        elif num == '3':
            # 일기 삭제
            diary.delete_diary()
        elif num == '4':
            # 작성한 일기 확인
            diary.show_diary()
        elif num == '5':
            # 종료하기
            break
        else:
            print('\n 잘못 선택하셨습니다, 다시 입력해주세요! >> ')

main()
# print_menu()